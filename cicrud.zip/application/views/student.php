<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
</head>
<body>
    <form method="POST" action="<?= base_url("home/savestudent"); ?>">
        <input type="hidden" id="id" name="id" value="<?= $id; ?>" />
        <input type="number" id="rollno" name="rollno" placeholder="Enter Roll No" value="<?= $id == 0 ? "" : $student->rollno; ?>" required />        <input type="text" id="name" name="name" placeholder="Enter Name" value="<?= $id == 0 ? "" : $student->name; ?>" required />
        <input type="number" id="mobileno" name="mobileno" placeholder="Enter Mobile No" value="<?= $id == 0 ? "" : $student->mobileno; ?>" required />
        <?php
            $year = "";
            if($id != 0)
            {
                $year = $student->eyear;
            }
        ?>
        <select id="year" name="year">
            <option value="FE" <?= ($year == "FE" ? "selected" : ""); ?>>FE</option>
            <option value="SE" <?= ($year == "SE" ? "selected" : ""); ?>>SE</option>
            <option value="TE" <?= ($year == "TE" ? "selected" : ""); ?>>TE</option>
            <option value="BE" <?= ($year == "BE" ? "selected" : ""); ?>>BE</option>
        </select>
        <label>
        <input type="radio" id="male" name="gender" value="Male" <?= $id == 0 ? "" : ($student->gender == "Male" ? "checked" : "") ?> required />Male</label>
        <label>
        <input type="radio" id="female" name="gender" value="Female" <?= $id == 0 ? "" : ($student->gender == "Female" ? "checked" : "") ?> required/>Female</label>
        <label>
        <input type="checkbox" id="cricket" name="cricket" value="Yes" <?= $id == 0 ? "" : ($student->cricket == "Yes" ? "checked" : "") ?> />Cricket</label>
        <label><input type="checkbox" id="chess" name="chess" value="Yes" <?= $id == 0 ? "" : ($student->chess == "Yes" ? "checked" : "") ?>/>Chess</label>
        <input type="submit" value="Save" />
    </form>
</body>
</html>