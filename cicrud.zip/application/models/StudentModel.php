<?php

class StudentModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function save()
    {
        //ORM - Object Relational Mapping
        $gender = "Male";
        if($this->input->post("gender") != null)
            $gender = $this->input->post("gender");
        $cricket = "No";
        if($this->input->post("cricket") != null)
            $cricket = "Yes";  
            
        $chess = "No";
        if($this->input->post("chess") != null)
            $chess = "Yes";  
        $id = $this->input->post("id");
        $field = array(
            'rollno'=>$this->input->post("rollno"),
            'name'=>$this->input->post("name"),
            'mobileno'=>$this->input->post("mobileno"),
            "eyear"=>$this->input->post("year"),
            "gender"=>$gender,
            "cricket"=>$cricket,
            "chess"=>$chess,
        );
        if($id == 0)
        {
            $this->db->insert('students', $field);
        }
        else{
            $this->db->where('id', $id);
            $this->db->update('students', $field);
        }
        echo "success";
    }

    public function lists()
    {
        $this->db->order_by("rollno");
        $result = $this->db->get("students");
        return $result->result();
        // $query = "SELECT * FROM students";
        // $result = $this->db->query($query);
        // return $result->result();
    }

    public function getbyid($id)
    {
        $this->db->where("id", $id);
        $result = $this->db->get("students");
        if($result->num_rows() == 0)
            return false;
        else
            return $result->row();
    }

    public function delete($id)
    {
        // $query = "DELETE FROM students WHERE id = "  .$id;
        // $this->db->query($query);
        $this->db->where("id", $id);
        $this->db->delete("students");
    }
}