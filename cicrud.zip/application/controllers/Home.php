<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
    {
		parent::__construct();
		$this->load->model("StudentModel", "student");
	}

	public function index()
	{
		$data["students"] = $this->student->lists();
		$this->load->view('students', $data);
	}

	public function student($id)
	{
		$data["id"] = $id;
		$data["student"] = $this->student->getbyid($id);
		$this->load->view('student', $data);
	}

	public function savestudent()
	{
		$this->student->save();
		redirect(base_url("home"));
	}

	public function deletestudent($id)
	{
		$this->student->delete($id);
		redirect(base_url("home"));
	}
}
